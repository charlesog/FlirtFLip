package com.example.flirtflip.data.di

import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

@Module
@InstallIn(SingletonComponent::class)
object NetworkModule
// FusedLocationProviderClient ya está provisto en LocationModule